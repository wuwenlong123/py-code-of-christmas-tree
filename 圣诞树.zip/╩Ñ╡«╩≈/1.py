from os import times
import turtle
import pygame
import random
from PIL import Image,ImageDraw,ImageFont
from pygame.display import iconify
'''
n = 100

turtle.setup(700, 700, 0, 0)
turtle.speed("fastest")
turtle.screensize(bg='black')
turtle.left(90)
turtle.forward(3 * n)
turtle.color("orange", "yellow")
turtle.begin_fill()
turtle.left(126)

for i in range(5):
    turtle.forward(n / 5)
    turtle.right(144)
    turtle.forward(n / 5)
    turtle.left(72)
turtle.end_fill()
turtle.right(126)
turtle.color("dark green")
turtle.backward(n * 4.8)

def tree(d, s):
    if d <= 0: return
    turtle.forward(s)
    tree(d - 1, s * .8)
    turtle.right(120)
    tree(d - 3, s * .5)
    turtle.right(120)
    tree(d - 3, s * .5)
    turtle.right(120)
    turtle.backward(s)
tree(15, n)
'''

infile = r"./yours.jpg"
outfile = r"./mine.jpg"
def transformer(infile,outfile):
    img = Image.open(infile)
    new_img = img.resize((600,1000))#图片的尺寸
    draw = ImageDraw.Draw(new_img)
    fontstyle = ImageFont.truetype("./simsunb.ttf",20,encoding="UTF-8")
    draw.text((190,250),"Love what you love",(255,0,0),font=fontstyle)
    new_img.save(outfile,quality = 95)
    

transformer(infile,outfile)#压缩图片，这里输入路径和输出路径采用同一张图片了

music = r"./薛之谦,郁一凡 - 如果说 (Live).mp3" #music！
pygame.mixer.init()
track = pygame.mixer.music.load(music)
pygame.mixer.music.play()

bg_img = r"./mine.jpg"#你的背景图片
bg_size = (600,600)#画布的尺寸，最好跟图片保持一致
screen = pygame.display.set_mode(bg_size)
pygame.display.set_caption("唯你圣诞树")#命名你的文件
bg = pygame.image.load(bg_img)

snow_list = []

for i in range(20):#循环个数调整雪花数量
    x_site = random.randrange(0, bg_size[0])   # 雪花圆心位置
    y_site = random.randrange(0, bg_size[1])   # 雪花圆心位置
    X_shift = random.randint(-1, 1)         # x 轴偏移量
    radius = random.randint(3,6)           # 半径和 y 周下降量
    snow_list.append([x_site, y_site, X_shift, radius])

done = False
while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
    screen.blit(bg,(0,-220))
    for i in range(len(snow_list)):
        # 绘制雪花，颜色、位置、大小
        pygame.draw.circle(screen, (255, 255, 255), snow_list[i][:2], snow_list[i][3] - 3)
        # 移动雪花位置（下一次循环起效）
        snow_list[i][0] += snow_list[i][2]
        snow_list[i][1] += snow_list[i][3]
        # 如果雪花落出屏幕，重设位置
        if snow_list[i][1] > bg_size[1]:
            snow_list[i][1] = random.randrange(-50, -10)
            snow_list[i][0] = random.randrange(0, bg_size[0])
    pygame.display.flip()

pygame.mixer.music.stop()
